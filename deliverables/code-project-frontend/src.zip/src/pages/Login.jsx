import React, { useState } from "react";

export default function Login({ onLoginSuccess }) {
  const [username, setUsername] = useState("Hannah Bautista");
  const [role, setRole] = useState("farmer");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!username.trim()) return alert("Please type an operator username profile name");
    onLoginSuccess({ username, role });
  };

  return (
    <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh", background: "#f3f4f6" }}>
      <form onSubmit={handleSubmit} style={{ background: "white", padding: "40px", borderRadius: "10px", boxShadow: "0 4px 10px rgba(0,0,0,0.1)", width: "100%", maxWidth: "400px" }}>
        <h2 style={{ textAlign: "center", color: "#111827", margin: "0 0 5px 0" }}>AgriTech Portal</h2>
        <p style={{ textAlign: "center", color: "#6b7280", fontSize: "14px", margin: "0 0 30px 0" }}>Sign in to manage field assets</p>
        
        <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          <div style={{ display: "flex", flexDirection: "column", gap: "5px" }}>
            <label style={{ fontWeight: "bold", fontSize: "14px", color: "#374151" }}>Operator Profile Name</label>
            <input 
              type="text" 
              value={username} 
              onChange={(e) => setUsername(e.target.value)}
              style={{ padding: "10px 12px", borderRadius: "6px", border: "1px solid #d1d5db", fontSize: "15px", color: "#1f2937" }}
            />
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: "5px" }}>
            <label style={{ fontWeight: "bold", fontSize: "14px", color: "#374151" }}>System Role Authority</label>
            <select 
              value={role} 
              onChange={(e) => setRole(e.target.value)}
              style={{ padding: "10px 12px", borderRadius: "6px", border: "1px solid #d1d5db", background: "white", fontSize: "15px", color: "#1f2937" }}
            >
              <option value="farmer">Farmer (Standard Field Access)</option>
              <option value="admin">Admin (System Global Access Overrides)</option>
            </select>
          </div>

          <button type="submit" style={{ background: "#1b4332", color: "white", padding: "12px", border: "none", borderRadius: "6px", fontSize: "16px", fontWeight: "bold", cursor: "pointer", marginTop: "10px" }}>
            Access Environment
          </button>
        </div>
      </form>
    </div>
  );
}