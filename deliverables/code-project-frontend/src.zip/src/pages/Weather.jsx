import React, { useState } from "react";
import axios from "axios";

export default function Weather() {
  const [city, setCity] = useState("Manila");
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const getWeather = async () => {
    if (!city) return;
    setLoading(true);
    setError("");
    
    try {
      const res = await axios.get(`http://localhost:5000/api/weather/${city}`);
      setData(res.data);
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.message || "City not found. Please try again.");
      setData(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ fontFamily: "Arial, sans-serif" }}>
      <h1 style={{ color: "#1b4332", margin: "0 0 10px 0", fontSize: "28px" }}>
        🌤 Weather Forecast Dashboard
      </h1>
      <p style={{ color: "#4b5563", fontSize: "15px" }}>
        Monitor localized atmospheric pressures and real-time precipitation metrics.
      </p>
      <hr style={{ margin: "20px 0", border: "0", borderTop: "1px solid #e5e7eb" }} />

      {/* Styled Search Group */}
      <div style={{ display: "flex", gap: "10px", marginBottom: "25px" }}>
        <input
          type="text"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          placeholder="Enter city name (e.g., Manila, Alcala)"
          style={{ 
            padding: "10px 15px", 
            borderRadius: "6px", 
            border: "1px solid #d1d5db", 
            width: "280px", 
            fontSize: "15px",
            color: "#1f2937",
            background: "#ffffff"
          }}
        />
        <button 
          onClick={getWeather} 
          style={{ 
            background: "#2d6a4f", 
            color: "white", 
            padding: "10px 22px", 
            border: "none", 
            borderRadius: "6px", 
            fontWeight: "bold", 
            cursor: "pointer", 
            fontSize: "15px" 
          }}
        >
          {loading ? "Searching..." : "Search"}
        </button>
      </div>

      {/* Error Messaging Display */}
      {error && (
        <div style={{ color: "#991b1b", background: "#fee2e2", padding: "12px", borderRadius: "6px", maxWidth: "450px", marginBottom: "20px", fontSize: "14px", border: "1px solid #fca5a5" }}>
          ⚠️ {error}
        </div>
      )}

      {/* FIXED CONDITION BLOCK USING CLEAN TERNARY LAYERS */}
      {data ? (
        <div style={{
          padding: "25px",
          background: "white",
          borderRadius: "8px",
          boxShadow: "0 4px 6px rgba(0,0,0,0.05)",
          border: "1px solid #e5e7eb",
          maxWidth: "450px"
        }}>
          <h2 style={{ margin: "0 0 15px 0", color: "#1b4332", fontSize: "22px" }}>{data.name}, {data.sys?.country}</h2>
          <div style={{ display: "flex", flexDirection: "column", gap: "12px", fontSize: "16px", color: "#374151" }}>
            <p style={{ margin: 0 }}><strong>🌡 Temperature:</strong> {data.main?.temp}°C (Feels like {data.main?.feels_like}°C)</p>
            <p style={{ margin: 0 }}><strong>💧 Humidity:</strong> {data.main?.humidity}%</p>
            <p style={{ margin: 0 }}><strong>💨 Wind Speed:</strong> {data.wind?.speed} m/s</p>
            <p style={{ margin: 0, textTransform: "capitalize" }}><strong>🌥 Condition:</strong> {data.weather?.[0]?.description}</p>
          </div>
        </div>
      ) : (
        !loading && (
          <div style={{ padding: "20px", background: "#f9fafb", borderRadius: "6px", border: "1px solid #f3f4f6", maxWidth: "450px", color: "#6b7280" }}>
            Enter a local municipality or regional capital above to pull current climatic values.
          </div>
        )
      )}
    </div>
  );
}