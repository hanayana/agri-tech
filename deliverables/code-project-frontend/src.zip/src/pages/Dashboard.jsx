import React from 'react';

const Dashboard = () => {
  return (
    <div className="dashboard-page">
      <h1>AgriTech Dashboard</h1>
      {/* Your dashboard layout and data cards go here */}
    </div>
  );
};

// CRUCIAL: This line fixes your exact console error
export default Dashboard;