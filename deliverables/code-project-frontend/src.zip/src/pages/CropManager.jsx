import React, { useState, useEffect } from "react";
import axios from "axios";

export default function CropManager({ currentRole }) {
  const [crops, setCrops] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [newName, setNewName] = useState("");
  const [newStatus, setNewStatus] = useState("Seedling Stage");
  const [newMoisture, setNewMoisture] = useState(60);

  const [editingId, setEditingId] = useState(null);
  const [editStatus, setEditStatus] = useState("Seedling Stage");
  const [editMoisture, setEditMoisture] = useState(60);

  const API_URL = "http://localhost:5000/api/crops";

  const fetchCrops = async () => {
    try {
      setLoading(true);
      const response = await axios.get(API_URL);
      setCrops(response.data);
    } catch (err) {
      setError("Could not safely sync with database documents.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { 
    fetchCrops(); 
  }, []);

  const handleAddCrop = async (e) => {
    e.preventDefault();
    if (!newName) return alert("Please specify a valid crop variety label.");
    try {
      const response = await axios.post(API_URL, { 
        name: newName, 
        status: newStatus, 
        moistureLevel: Number(newMoisture) 
      });
      setCrops([...crops, response.data]);
      setNewName("");
    } catch (err) { 
      setError("Failed to construct database record mapping."); 
    }
  };

  const handleSaveUpdate = async (id) => {
    try {
      const response = await axios.put(`${API_URL}/${id}`, { 
        status: editStatus, 
        moistureLevel: Number(editMoisture) 
      });
      setCrops(crops.map(item => item._id === id ? response.data : item));
      setEditingId(null);
    } catch (err) { 
      setError("Modification failure sync."); 
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Drop this specimen documentation row entirely from database logs?")) return;
    try {
      await axios.delete(`${API_URL}/${id}`);
      setCrops(crops.filter(item => item._id !== id));
    } catch (err) { 
      setError("Document deletion failure tracking."); 
    }
  };

  return (
    <div style={{ fontFamily: "Arial, sans-serif" }}>
      {/* High contrast dark header */}
      <h1 style={{ color: "#1b4332", margin: "0 0 10px 0", fontSize: "28px" }}>
        🌱 Crop Lifecycle Control Center
      </h1>
      <p style={{ color: "#4b5563", fontSize: "15px" }}>
        Perform continuous database manipulations mapped live to remote cluster objects.
      </p>
      <hr style={{ margin: "20px 0", border: 0, borderTop: "1px solid #e5e7eb" }} />

      {error && (
        <div style={{ color: "#991b1b", background: "#fee2e2", padding: "12px", borderRadius: "6px", marginBottom: "20px", border: "1px solid #fca5a5" }}>
          {error}
        </div>
      )}

      {currentRole === "admin" ? (
        <div style={{ background: "#eff6ff", color: "#1e40af", padding: "15px", borderRadius: "6px", marginBottom: "25px", border: "1px solid #bfdbfe" }}>
          ℹ️ <strong>System Notice:</strong> You are logged in with Admin Role Credentials. Table modifications are restricted to field workers.
        </div>
      ) : (
        /* Styled high-contrast action container block */
        <form onSubmit={handleAddCrop} style={{ 
          display: "flex", 
          gap: "20px", 
          background: "white", 
          padding: "20px", 
          borderRadius: "8px", 
          boxShadow: "0 2px 4px rgba(0,0,0,0.05)", 
          marginBottom: "30px", 
          alignItems: "flex-end", 
          border: "1px solid #e5e7eb" 
        }}>
          <div>
            <label style={{ display: "block", fontWeight: "bold", marginBottom: "8px", fontSize: "14px", color: "#374151" }}>Crop Name</label>
            <input 
              type="text" 
              value={newName} 
              onChange={(e) => setNewName(e.target.value)} 
              placeholder="e.g., Rice, Corn" 
              style={{ padding: "10px 12px", borderRadius: "6px", border: "1px solid #d1d5db", fontSize: "14px", color: "#1f2937", background: "#ffffff", width: "200px" }} 
            />
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "bold", marginBottom: "8px", fontSize: "14px", color: "#374151" }}>Cycle Status</label>
            <select 
              value={newStatus} 
              onChange={(e) => setNewStatus(e.target.value)} 
              style={{ padding: "10px 12px", borderRadius: "6px", border: "1px solid #d1d5db", background: "#ffffff", fontSize: "14px", color: "#1f2937", height: "41px" }}
            >
              <option value="Seedling Stage">Seedling Stage</option>
              <option value="Vegetative Stage">Vegetative Stage</option>
              <option value="Flowering Stage">Flowering Stage</option>
              <option value="Harvest Ready">Harvest Ready</option>
            </select>
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "bold", marginBottom: "8px", fontSize: "14px", color: "#374151" }}>Moisture Level (%)</label>
            <input 
              type="number" 
              value={newMoisture} 
              onChange={(e) => setNewMoisture(e.target.value)} 
              style={{ padding: "10px 12px", borderRadius: "6px", border: "1px solid #d1d5db", width: "90px", fontSize: "14px", color: "#1f2937", background: "#ffffff" }} 
            />
          </div>
          <button type="submit" style={{ background: "#2d6a4f", color: "white", padding: "11px 24px", border: "none", borderRadius: "6px", fontWeight: "bold", cursor: "pointer", fontSize: "14px" }}>
            Save
          </button>
        </form>
      )}

      {loading ? (
        <p style={{ color: "#2d6a4f", fontWeight: "bold" }}>Synchronizing data grids...</p>
      ) : (
        /* Table Layout Styling Fixes */
        <table style={{ width: "100%", borderCollapse: "collapse", background: "white", borderRadius: "8px", overflow: "hidden", boxShadow: "0 2px 4px rgba(0,0,0,0.05)", border: "1px solid #e5e7eb" }}>
          <thead style={{ background: "#f9fafb", textAlign: "left", borderBottom: "2px solid #e5e7eb" }}>
            <tr>
              <th style={{ padding: "15px", color: "#4b5563", fontSize: "14px", fontWeight: "bold" }}>Crop Specimen Variety</th>
              <th style={{ padding: "15px", color: "#4b5563", fontSize: "14px", fontWeight: "bold" }}>Growth Matrix Stage</th>
              <th style={{ padding: "15px", color: "#4b5563", fontSize: "14px", fontWeight: "bold" }}>Hydration Stat Value</th>
              <th style={{ padding: "15px", color: "#4b5563", fontSize: "14px", fontWeight: "bold" }}>Operations Management Controls</th>
            </tr>
          </thead>
          <tbody>
            {crops.length === 0 ? (
              <tr>
                <td colSpan="4" style={{ padding: "20px", textAlign: "center", color: "#6b7280" }}>
                  No matching fields registered inside local database collections yet.
                </td>
              </tr>
            ) : (
              crops.map((item) => (
                <tr key={item._id} style={{ borderBottom: "1px solid #e5e7eb" }}>
                  <td style={{ padding: "15px", fontWeight: "bold", color: "#111827" }}>{item.name}</td>
                  <td style={{ padding: "15px", color: "#374151" }}>
                    {editingId === item._id ? (
                      <select value={editStatus} onChange={(e) => setEditStatus(e.target.value)} style={{ padding: "6px", borderRadius: "4px", color: "#1f2937", background: "#ffffff" }}>
                        <option value="Seedling Stage">Seedling Stage</option>
                        <option value="Vegetative Stage">Vegetative Stage</option>
                        <option value="Flowering Stage">Flowering Stage</option>
                        <option value="Harvest Ready">Harvest Ready</option>
                      </select>
                    ) : (
                      item.status
                    )}
                  </td>
                  <td style={{ padding: "15px", color: "#374151" }}>
                    {editingId === item._id ? (
                      <input type="number" value={editMoisture} onChange={(e) => setEditMoisture(e.target.value)} style={{ padding: "6px", width: "70px", color: "#1f2937", background: "#ffffff" }} />
                    ) : (
                      `${item.moistureLevel || 0}%`
                    )}
                  </td>
                  <td style={{ padding: "15px" }}>
                    {editingId === item._id ? (
                      <>
                        <button onClick={() => handleSaveUpdate(item._id)} style={{ background: "#16a34a", color: "white", padding: "6px 12px", border: "none", borderRadius: "4px", marginRight: "8px", cursor: "pointer", fontWeight: "bold" }}>Confirm</button>
                        <button onClick={() => setEditingId(null)} style={{ background: "#4b5563", color: "white", padding: "6px 12px", border: "none", borderRadius: "4px", cursor: "pointer" }}>Cancel</button>
                      </>
                    ) : (
                      <>
                        <button onClick={() => { setEditingId(item._id); setEditStatus(item.status); setEditMoisture(item.moistureLevel); }} style={{ background: "#eab308", color: "black", padding: "6px 12px", border: "none", borderRadius: "4px", marginRight: "8px", cursor: "pointer", fontWeight: "bold" }}>Edit</button>
                        <button onClick={() => handleDelete(item._id)} style={{ background: "#ef4444", color: "white", padding: "6px 12px", border: "none", borderRadius: "4px", cursor: "pointer", fontWeight: "bold" }}>Delete</button>
                      </>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      )}
    </div>
  );
}