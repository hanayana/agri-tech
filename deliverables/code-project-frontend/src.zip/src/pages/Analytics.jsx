import React from "react";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function Analytics() {
  const data = [
    { month: "Jan", yieldVolume: 420, fieldHumidity: 72 },
    { month: "Feb", yieldVolume: 490, fieldHumidity: 64 },
    { month: "Mar", yieldVolume: 530, fieldHumidity: 55 },
    { month: "Apr", yieldVolume: 610, fieldHumidity: 48 },
    { month: "May", yieldVolume: 570, fieldHumidity: 66 },
  ];

  return (
    <div>
      <h1 style={{ color: "#111827", margin: "0 0 10px 0", fontSize: "28px" }}>📊 System Metrics & Visual Analytics</h1>
      <p style={{ color: "#6c757d" }}>Review historical trends and performance indicators mapped from field data arrays.</p>
      <hr style={{ margin: "20px 0", border: 0, borderTop: "1px solid #e5e7eb" }} />

      <div style={{ display: "flex", gap: "30px", flexWrap: "wrap", marginTop: "25px" }}>
        
        {/* Metric Chart 1 */}
        <div style={{ background: "white", padding: "20px", borderRadius: "8px", boxShadow: "0 2px 4px rgba(0,0,0,0.05)", width: "100%", maxWidth: "480px", border: "1px solid #e5e7eb" }}>
          <h3 style={{ margin: "0 0 15px 0", color: "#374151", fontSize: "16px" }}>Seasonal Crop Output Yield</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
              <XAxis dataKey="month" tick={{ fill: "#6b7280", fontSize: 12 }} />
              <YAxis tick={{ fill: "#6b7280", fontSize: 12 }} />
              <Tooltip />
              <Legend />
              <Bar dataKey="yieldVolume" fill="#1b4332" name="Metric Tons (MT)" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Metric Chart 2 */}
        <div style={{ background: "white", padding: "20px", borderRadius: "8px", boxShadow: "0 2px 4px rgba(0,0,0,0.05)", width: "100%", maxWidth: "480px", border: "1px solid #e5e7eb" }}>
          <h3 style={{ margin: "0 0 15px 0", color: "#374151", fontSize: "16px" }}>Ambient Atmospheric Humidity Index</h3>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
              <XAxis dataKey="month" tick={{ fill: "#6b7280", fontSize: 12 }} />
              <YAxis tick={{ fill: "#6b7280", fontSize: 12 }} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="fieldHumidity" stroke="#0284c7" strokeWidth={2.5} name="Humidity %" />
            </LineChart>
          </ResponsiveContainer>
        </div>

      </div>
    </div>
  );
}