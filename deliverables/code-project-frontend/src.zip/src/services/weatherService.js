import axios from "axios";

const API = "http://localhost:5000/api/weather";

export const getWeather = (city) => {
  return axios.get(`${API}/${city}`);
};