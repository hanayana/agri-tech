import React, { useState } from "react";
import Weather from "./pages/Weather.jsx";
import CropManager from "./pages/CropManager.jsx";
import Analytics from "./pages/Analytics.jsx";
import Login from "./pages/Login.jsx";

export default function App() {
  // Authentication states
  const [user, setUser] = useState(null); // stores { username: "", role: "farmer" | "admin" }
  const [activeTab, setActiveTab] = useState("dashboard");

  // Force show the login module interface if credentials are unverified
  if (!user) {
    return <Login onLoginSuccess={(userData) => setUser(userData)} />;
  }

  return (
    <div style={{ display: "flex", fontFamily: "Arial, sans-serif", minHeight: "100vh", margin: 0 }}>
      
      {/* Sidebar Navigation Panel */}
      <div style={{
        width: "260px",
        background: user.role === "admin" ? "#1e3a8a" : "#1b4332", // Dark Blue theme for Admin, Classic Forest Green for Farmer
        color: "white",
        padding: "25px 20px",
        boxSizing: "border-box",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between"
      }}>
        <div>
          <h2 style={{ margin: "0 0 5px 0", display: "flex", alignItems: "center", gap: "10px" }}>
            🌾 AgriTech
          </h2>
          <span style={{
            fontSize: "11px", 
            background: "rgba(255,255,255,0.2)", 
            padding: "3px 8px", 
            borderRadius: "4px",
            textTransform: "uppercase",
            fontWeight: "bold",
            letterSpacing: "0.5px"
          }}>
            {user.role} mode
          </span>
          <p style={{ fontSize: "14px", color: "#e5e7eb", margin: "15px 0 30px 0" }}>
            Hello, <strong>{user.username}</strong>
          </p>
          
          <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
            <button 
              onClick={() => setActiveTab("dashboard")} 
              style={{ background: activeTab === "dashboard" ? "rgba(255,255,255,0.15)" : "transparent", color: "white", border: "none", padding: "12px", borderRadius: "6px", textAlign: "left", cursor: "pointer", fontSize: "15px" }}>
              📊 Dashboard Summary
            </button>
            
            <button 
              onClick={() => setActiveTab("crops")} 
              style={{ background: activeTab === "crops" ? "rgba(255,255,255,0.15)" : "transparent", color: "white", border: "none", padding: "12px", borderRadius: "6px", textAlign: "left", cursor: "pointer", fontSize: "15px" }}>
              🌱 Crop Management
            </button>

            <button 
              onClick={() => setActiveTab("analytics")} 
              style={{ background: activeTab === "analytics" ? "rgba(255,255,255,0.15)" : "transparent", color: "white", border: "none", padding: "12px", borderRadius: "6px", textAlign: "left", cursor: "pointer", fontSize: "15px" }}>
              📈 Visual Analytics
            </button>
            
            <button 
              onClick={() => setActiveTab("weather")} 
              style={{ background: activeTab === "weather" ? "rgba(255,255,255,0.15)" : "transparent", color: "white", border: "none", padding: "12px", borderRadius: "6px", textAlign: "left", cursor: "pointer", fontSize: "15px" }}>
              🌤 Weather Forecast
            </button>
          </div>
        </div>

        <button 
          onClick={() => setUser(null)} 
          style={{ background: "#dc2626", color: "white", border: "none", padding: "12px", borderRadius: "6px", cursor: "pointer", fontWeight: "bold", fontSize: "14px" }}
        >
          Logout Session
        </button>
      </div>

      {/* Main Content Workspace Frame */}
      <div style={{ padding: "40px", flex: 1, background: "#f8f9fa" }}>
        {activeTab === "dashboard" && (
          <div>
            <h1 style={{ color: "#111827", margin: "0 0 10px 0", fontSize: "32px" }}>Welcome Back, Farmer!</h1>
            <p style={{ color: "#6c757d", fontSize: "16px" }}>Here is a quick overview of your digital farm ecosystem status today.</p>
            <hr style={{ margin: "25px 0", border: 0, borderTop: "1px solid #e5e7eb" }} />
            
            <div style={{ display: "flex", gap: "20px", marginTop: "20px" }}>
              <div style={{ background: "white", padding: "25px", borderRadius: "8px", boxShadow: "0 2px 4px rgba(0,0,0,0.05)", flex: 1, border: "1px solid #e5e7eb" }}>
                <h3 style={{ margin: "0 0 10px 0", color: "#6b7280", fontSize: "14px", textTransform: "uppercase" }}>System Status</h3>
                <p style={{ fontSize: "28px", fontWeight: "bold", color: user.role === "admin" ? "#1e3a8a" : "#2d6a4f", margin: 0 }}>Online & Secured</p>
              </div>
              <div style={{ background: "white", padding: "25px", borderRadius: "8px", boxShadow: "0 2px 4px rgba(0,0,0,0.05)", flex: 1, border: "1px solid #e5e7eb" }}>
                <h3 style={{ margin: "0 0 10px 0", color: "#6b7280", fontSize: "14px", textTransform: "uppercase" }}>Assigned Environment Role</h3>
                <p style={{ fontSize: "28px", fontWeight: "bold", color: "#b45309", margin: 0, textTransform: "capitalize" }}>{user.role} Portal</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === "crops" && <CropManager currentRole={user.role} />}
        {activeTab === "analytics" && <Analytics />}
        {activeTab === "weather" && <Weather />}
      </div>
    </div>
  );
}